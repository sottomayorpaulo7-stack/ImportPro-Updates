# Verifica as tabelas oficiais de ISV (Código do ISV, artigos 7.º e 11.º) no site das Finanças
import re, json, os, time, hashlib, urllib.request

URL_CISV = "https://info-aduaneiro.portaldasfinancas.gov.pt/pt/legislacao_aduaneira/codigos_aduaneiros/Documents/CISV.pdf"

# tabelas que vêm no programa (Lei 82/2023, em vigor em 2026). None = "mais de"
BASE = {
 "cil": [[1000, 1.09, 849.03], [1250, 1.18, 850.69], [None, 5.61, 6194.88]],
 "nedc_g": [[99, 4.62, 427.00], [115, 8.09, 750.99], [145, 52.56, 5903.94], [175, 61.24, 7140.17], [195, 155.97, 23627.27], [None, 205.65, 33390.12]],
 "nedc_d": [[79, 5.78, 439.04], [95, 23.45, 1848.58], [120, 79.22, 7195.63], [140, 175.73, 18924.92], [160, 195.43, 21720.92], [None, 268.42, 33447.90]],
 "wltp_g": [[110, .44, 43.02], [115, 1.10, 115.80], [120, 1.38, 147.79], [130, 5.27, 619.17], [145, 6.38, 762.73], [175, 41.54, 5819.56], [195, 51.38, 7247.39], [235, 193.01, 34190.52], [None, 233.81, 41910.96]],
 "wltp_d": [[110, 1.72, 11.50], [120, 18.96, 1906.19], [140, 65.04, 7360.85], [150, 127.40, 16080.57], [160, 160.81, 21176.06], [170, 221.69, 29227.38], [190, 274.08, 36987.98], [None, 282.35, 38271.32]],
 "tabD": [[1, .10], [2, .20], [3, .28], [4, .35], [5, .43], [6, .52], [7, .60], [8, .65], [9, .70], [10, .75], [None, .80]],
}

def _num(s):
    s = s.strip().replace(" ", " ").replace(" ", "").replace(".", "").replace(",", ".")
    return float(s)

def _limite(txt):
    t = txt.lower().replace(" ", " ")
    if t.strip().startswith("mais de") and not re.search(r"\ba\b\s*\d", t): return None
    nums = re.findall(r"\d[\d ]*", t)
    return int(nums[-1].replace(" ", "")) if nums else None

def _tabelas(md):
    out, cur = [], []
    for linha in md.splitlines():
        l = linha.strip()
        if l.startswith("|"):
            cur.append([c.strip() for c in l.strip("|").split("|")])
        elif cur:
            out.append(cur); cur = []
    if cur: out.append(cur)
    return [[r for r in t[1:] if not set("".join(r)) <= set("-: ")] for t in out]

def ler(md):
    """Devolve as tabelas lidas do texto do Código do ISV, ou levanta erro se o formato não for o esperado."""
    a = md.find("TABELA A"); b = md.find("TABELA B", a)
    if a < 0 or b < 0: raise ValueError("não encontrei a Tabela A")
    ts = _tabelas(md[a:b])
    if len(ts) != 5: raise ValueError("esperava 5 tabelas na Tabela A, encontrei %d" % len(ts))
    res = {}
    for nome, t in zip(["cil", "nedc_g", "nedc_d", "wltp_g", "wltp_d"], ts):
        linhas = [[_limite(r[0]), _num(r[1]), _num(r[2])] for r in t]
        if len(linhas) < 2 or linhas[-1][0] is not None or any(x[0] is None for x in linhas[:-1]):
            raise ValueError("formato inesperado em " + nome)
        res[nome] = linhas
    d = md.find("TABELA D")
    if d >= 0:
        td = _tabelas(md[d:d + 3000])
        if td:
            linhas = []
            for r in td[0]:
                t = r[0].lower()
                lim = None if (t.startswith("mais de") and " a " not in t) else int(re.findall(r"\d+", t)[-1])
                linhas.append([lim, _num(r[1]) / 100])
            if len(linhas) >= 5 and linhas[-1][0] is None: res["tabD"] = linhas
    if "tabD" not in res: res["tabD"] = BASE["tabD"]
    return res

# tabelas confirmadas no documento oficial em 12/11/2026: servem de ponto de partida, para que a
# primeira verificação seja só a descarga grátis do PDF (sem ler 18 páginas com o Firecrawl)
SEMENTE = "2026-11-12"

def iguais(a, b):
    return json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)

def verificar(pasta, chave, firecrawl):
    """firecrawl(url, opcoes) -> markdown. Grava o resultado em isv.json e devolve o estado."""
    f = os.path.join(pasta, "isv.json")
    try:
        with open(f, encoding="utf-8") as h: est = json.load(h)
    except Exception: est = {}
    hoje = time.strftime("%Y-%m-%d")
    est.update({"a_verificar": False})
    if not est.get("tabelas"):
        est.update({"tabelas": BASE, "lido_em": SEMENTE, "semente": True, "diferente_da_base": False, "erro": None})
    hash_pdf = None
    try:   # 1) descarrega o PDF oficial diretamente (grátis) para ver se mudou
        req = urllib.request.Request(URL_CISV, headers={"User-Agent": "Mozilla/5.0 ImportPro"})
        try:
            with urllib.request.urlopen(req, timeout=20) as r: dados = r.read()
        except urllib.error.URLError as e:
            # alguns PCs Windows não têm o certificado intermédio do Portal das Finanças:
            # o PDF só serve para ver se mudou (as tabelas são lidas pelo Firecrawl), por isso tenta sem validar
            if "CERTIFICATE" not in str(e).upper(): raise
            import ssl
            with urllib.request.urlopen(req, timeout=20, context=ssl._create_unverified_context()) as r: dados = r.read()
        if not dados.startswith(b"%PDF"): raise ValueError("o site não devolveu o PDF")
        hash_pdf = hashlib.sha256(dados).hexdigest()
        est.pop("aviso_download", None)
    except Exception as e:
        est["aviso_download"] = str(e)
    precisa_ler = (not est.get("tabelas")) or (hash_pdf and hash_pdf != est.get("hash")) or \
                  (not hash_pdf and est.get("lido_em", "") < time.strftime("%Y-%m-%d", time.localtime(time.time() - 7 * 86400)))
    if est.get("semente") and hash_pdf and not est.get("hash") and \
            time.strftime("%Y-%m-%d", time.localtime(time.time() - 90 * 86400)) < SEMENTE:
        est["hash"] = hash_pdf; est.pop("semente", None); precisa_ler = False
    if precisa_ler and chave:
        try:   # 2) só quando o documento mudou: lê as tabelas com o Firecrawl
            md = firecrawl(URL_CISV, {"formats": ["markdown"], "parsers": [{"type": "pdf", "maxPages": 18}], "onlyMainContent": False, "timeout": 150000})
            tab = ler(md)
            novo = not iguais(tab, est.get("tabelas") or BASE)
            if novo and not iguais(tab, BASE): est["mudou_em"] = hoje
            est.pop("semente", None); est.update({"tabelas": tab, "lido_em": hoje, "hash": hash_pdf, "erro": None,
                        "diferente_da_base": not iguais(tab, BASE)})
        except Exception as e:
            est["erro"] = "Não consegui ler as tabelas oficiais: %s" % e
    elif not est.get("tabelas"):
        est["erro"] = est.get("erro") or "Falta a chave do Firecrawl para ler as tabelas oficiais."
    if hash_pdf and hash_pdf == est.get("hash"): est["erro"] = None
    est["verificado_em"] = hoje if (hash_pdf or not precisa_ler or not est.get("erro")) else est.get("verificado_em")
    est["fonte"] = URL_CISV
    with open(f, "w", encoding="utf-8") as h: json.dump(est, h)
    return est
