# Cria o atalho e o lancador do ImportPro (corre a partir do instalador)
$ErrorActionPreference = 'Stop'
$dest = $env:DEST
$pyw = Join-Path (Split-Path $env:PYEXE) 'pythonw.exe'
if (-not (Test-Path $pyw)) { $pyw = $env:PYEXE }
$srv = Join-Path $dest 'servidor.py'
$q = [char]34
$vbs = 'CreateObject(' + $q + 'WScript.Shell' + $q + ').Run ' + $q + $q + $q + $pyw + $q + $q + ' ' + $q + $q + $srv + $q + $q + $q + ', 0, False'
[IO.File]::WriteAllText((Join-Path $dest 'abrir.vbs'), $vbs, [Text.Encoding]::Default)
$sh = New-Object -ComObject WScript.Shell
foreach ($pasta in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) { foreach ($n in @('Importa Console.lnk','Import Invest.lnk','ImportPro.lnk')) { $velho = Join-Path $pasta $n; if (Test-Path $velho) { Remove-Item $velho -Force } } }
foreach ($pasta in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  if (-not $pasta) { continue }
  $l = $sh.CreateShortcut((Join-Path $pasta 'ImportPro.lnk'))
  $l.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
  $l.Arguments = $q + (Join-Path $dest 'abrir.vbs') + $q
  $l.WorkingDirectory = $dest
  $l.IconLocation = (Join-Path $dest 'importpro.ico') + ',0'
  $l.Description = 'ImportPro'
  $l.Save()
}

# apaga o icone antigo e manda o Windows atualizar a cache de icones
$antigo = Join-Path $dest 'icone.ico'; if (Test-Path $antigo) { Remove-Item $antigo -Force }
try { Start-Process -FilePath (Join-Path $env:WINDIR 'System32\ie4uinit.exe') -ArgumentList '-show' -WindowStyle Hidden -Wait } catch {}
