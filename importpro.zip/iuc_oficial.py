"""Verifica no Código do IUC (Portal das Finanças) se as tabelas do IUC (art. 9.º e 10.º) mudaram."""
import re, json, os, time, hashlib, urllib.request, urllib.error

URL_CIUC = "https://info.portaldasfinancas.gov.pt/pt/informacao_fiscal/codigos_tributarios/Cod_download/Documents/IUC.pdf"
# tabelas em vigor em 2026 (Lei n.º 82/2023; sem alterações no OE 2026)
BASE = {
    "B_cil_lim": [1250, 1750, 2500], "B_cil": [31.77, 63.74, 127.35, 435.84],
    "B_nedc": [120, 180, 250], "B_wltp": [140, 205, 260], "B_co2": [65.15, 97.63, 212.04, 363.25],
    "B_ad2017": [31.77, 63.74],
    "B_coef": {"2007": 1.0, "2008": 1.05, "2009": 1.10, "2010": 1.15},
    "A_gas_lim": [1000, 1300, 1750, 2600, 3500], "A_out_lim": [1500, 2000, 3000],
    "A_pos95": [19.90, 39.95, 62.40, 158.31, 287.49, 512.23], "A_90_95": [12.55, 22.45, 34.87, 83.49, 156.54, 263.11],
    "A_81_89": [8.80, 12.55, 17.49, 36.09, 79.72, 120.90],
}

def _n(s): return float(s.replace(" ", "").replace(".", "").replace(",", "."))
def _ints(s): return [int(x.replace(" ", "")) for x in re.findall(r"\d[\d ]*\d|\d", s)]

def _tabelas(md):
    out, atual = [], None
    for linha in md.splitlines():
        l = linha.strip()
        if l.startswith("|") and l.endswith("|"):
            cel = [c.strip() for c in l.strip("|").split("|")]
            if atual is None: atual = []
            if not all(set(c) <= set("-: ") for c in cel): atual.append(cel)
        elif atual is not None:
            out.append(atual); atual = None
    if atual: out.append(atual)
    return out

def ler(md):
    # o PDF começa com um índice (e com a lei de aprovação) que também fala dos artigos 9.º a 11.º:
    # as tabelas estão a seguir à ÚLTIMA ocorrência de "Taxas - categoria A"
    a = max(md.rfind("Taxas - categoria A"), md.rfind("Taxas – categoria A"))
    if a < 0: raise ValueError("não encontrei os artigos 9.º e 10.º")
    b = md.find("Taxas - categoria C", a)
    ts = _tabelas(md[a:b if b > 0 else len(md)])
    try:
        tA = next(t for t in ts if t and "Gasolina" in t[0][0])[1:]
        tB = next(t for t in ts if t and "cilindrada" in t[0][0].lower() and len(t[0]) == 5)[1:]
        tAd = next(t for t in ts if t and len(t[0]) == 3 and "NEDC" in t[0][0])[1:]
        tC = next(t for t in ts if t and "Coeficiente" in " ".join(t[0]))[1:]
    except StopIteration:
        raise ValueError("não encontrei as tabelas dos artigos 9.º e 10.º no documento")
    if len(tA) != 6 or len(tB) != 4 or len(tAd) != 2 or len(tC) < 4: raise ValueError("formato inesperado das tabelas")
    up = lambda s: _ints(s)[-1]
    r = {
        "B_cil_lim": [up(x[0]) for x in tB[:3]], "B_cil": [_n(x[1]) for x in tB],
        "B_nedc": [up(x[2]) for x in tB[:3]], "B_wltp": [up(x[3]) for x in tB[:3]], "B_co2": [_n(x[4]) for x in tB],
        "B_ad2017": [_n(x[2]) for x in tAd],
        "B_coef": {re.search(r"\d{4}", x[0]).group(0): _n(x[1]) for x in tC},
        "A_gas_lim": [up(x[0]) for x in tA[:5]], "A_out_lim": [up(x[1]) for x in tA[:3]],
        "A_pos95": [_n(x[3]) for x in tA], "A_90_95": [_n(x[4]) for x in tA], "A_81_89": [_n(x[5]) for x in tA],
    }
    return r

# tabelas confirmadas no documento oficial em 12/11/2026: servem de ponto de partida, para que a
# primeira verificação seja só a descarga grátis do PDF (sem ler 18 páginas com o Firecrawl)
SEMENTE = "2026-11-12"

def iguais(a, b): return json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)

def verificar(pasta, chave, firecrawl):
    f = os.path.join(pasta, "iuc.json")
    try:
        with open(f, encoding="utf-8") as h: est = json.load(h)
    except Exception: est = {}
    hoje = time.strftime("%Y-%m-%d")
    if not est.get("tabelas"):
        est.update({"tabelas": BASE, "lido_em": SEMENTE, "semente": True, "diferente_da_base": False, "erro": None})
    hash_pdf = None
    try:
        req = urllib.request.Request(URL_CIUC, headers={"User-Agent": "Mozilla/5.0 ImportPro"})
        try:
            with urllib.request.urlopen(req, timeout=20) as r: dados = r.read()
        except urllib.error.URLError as e:
            if "CERTIFICATE" not in str(e).upper(): raise
            import ssl
            with urllib.request.urlopen(req, timeout=20, context=ssl._create_unverified_context()) as r: dados = r.read()
        if not dados.startswith(b"%PDF"): raise ValueError("o site não devolveu o PDF")
        hash_pdf = hashlib.sha256(dados).hexdigest(); est.pop("aviso_download", None)
    except Exception as e:
        est["aviso_download"] = str(e)
    precisa = (not est.get("tabelas")) or (hash_pdf and hash_pdf != est.get("hash")) or \
              (not hash_pdf and est.get("lido_em", "") < time.strftime("%Y-%m-%d", time.localtime(time.time() - 7 * 86400)))
    if est.get("semente") and hash_pdf and not est.get("hash") and \
            time.strftime("%Y-%m-%d", time.localtime(time.time() - 90 * 86400)) < SEMENTE:
        est["hash"] = hash_pdf; est.pop("semente", None); precisa = False
    if precisa and chave:
        try:
            md = firecrawl(URL_CIUC, {"formats": ["markdown"], "parsers": [{"type": "pdf", "maxPages": 18}], "onlyMainContent": False, "timeout": 150000})
            tab = ler(md)
            if not iguais(tab, est.get("tabelas") or BASE) and not iguais(tab, BASE): est["mudou_em"] = hoje
            est.pop("semente", None); est.update({"tabelas": tab, "lido_em": hoje, "hash": hash_pdf, "erro": None, "diferente_da_base": not iguais(tab, BASE)})
        except Exception as e:
            est["erro"] = "Não consegui ler as tabelas oficiais do IUC: %s" % e
    elif not est.get("tabelas"):
        est["erro"] = est.get("erro") or "Falta a chave do Firecrawl para ler as tabelas oficiais do IUC."
    if hash_pdf and hash_pdf == est.get("hash"): est["erro"] = None
    est["verificado_em"] = hoje if (hash_pdf or not precisa or not est.get("erro")) else est.get("verificado_em")
    est["fonte"] = URL_CIUC
    with open(f, "w", encoding="utf-8") as h: json.dump(est, h)
    return est
