# Relatório Excel do Carvest (sem dependências: usa xlsx_simples)
import datetime
from xlsx_simples import Livro, _col

AZUL = "1F6FE0"; ESCURO = "0D1A2B"; CINZA = "6B7480"; LINHA = "E6E8EC"; FUNDO = "F5F6F8"; LISTA = "F8FAFC"
VERDE = "1F9D55"; VERMELHO = "D93636"; AMBAR = "B07800"; VERDE_F = "E3F4EA"; VERM_F = "FBE5E5"; AMBAR_F = "FFF4DC"
EUR = '#,##0 "€";[Red]-#,##0 "€"'; PCT = '0.0%;[Red]-0.0%'; KM = '#,##0 "km"'

def km_txt(v): return "{:,}".format(int(v or 0)).replace(",", ".")

def gerar(d, caminho):
    L = Livro(); E = L.estilos.get
    crit = d.get("criterios", {}); modo = d.get("modo", "cons")
    agora = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")
    desc = "%s %s · %s–%s · até %s km" % (crit.get("marca", ""), crit.get("modelo", ""), crit.get("anoDe", ""), crit.get("anoAte", ""), km_txt(crit.get("km")))
    if crit.get("marca") == "Favoritos": desc = "Favoritos %s" % crit.get("modelo", "")
    if crit.get("versao"): desc += " · versão “%s”" % crit["versao"]
    if crit.get("pDe") or crit.get("pAte"): desc += " · preço %s a %s €" % (crit.get("pDe") or 0, crit.get("pAte") or "∞")
    anuncios = d.get("anuncios", []); ch = "c" if modo == "cons" else "s"
    nome_modo = "À consignação" if modo == "cons" else "Como stand"
    roi_alvo = d.get("roiAlvo", 0.08)

    def titulo(f, texto, sub, ncols):
        f.fundir.append("A1:%s1" % _col(ncols)); f.fundir.append("A2:%s2" % _col(ncols))
        for c in range(1, ncols + 1): f.set(1, c, None, E(fundo=ESCURO))
        f.set(1, 1, texto, E(negrito=True, cor="FFFFFF", tam=18, fundo=ESCURO, recuo=1)); f.alturas[1] = 40
        f.set(2, 1, sub, E(cor=CINZA, tam=10, recuo=1)); f.alturas[2] = 22

    def situacao(m):
        if m["lucro"] is None: return "Sem referência PT"
        if m["roi"] is not None and m["roi"] >= roi_alvo: return "Bom negócio"
        return "Margem curta" if m["lucro"] > 0 else "Prejuízo"

    # ======================= RESUMO =======================
    f = L.folha("Resumo")
    for c, w in enumerate([3, 30, 22, 14, 30, 22, 16, 24], 1): f.larguras[c] = w
    titulo(f, "Carvest · Relatório de importação", "%s   |   Gerado em %s   |   Vista: %s" % (desc, agora, nome_modo), 8)
    com_ref = [a for a in anuncios if a[ch]["lucro"] is not None]
    com_lucro = [a for a in com_ref if a[ch]["lucro"] > 0]
    vendas = sorted(a[ch]["venda"] for a in com_ref)
    med = vendas[len(vendas) // 2] if vendas else None
    bons = sorted([a for a in com_ref if not a.get("suspeito") and a.get("danosNivel") not in ("grave", "reparado") and "Fora da UE" not in a.get("danos", "")], key=lambda a: -a[ch]["lucro"])
    kpis = [("Anúncios de stands", len(anuncios), "0", ESCURO), ("Com preço de referência em PT", len(com_ref), "0", ESCURO),
            ("Com lucro (%s)" % nome_modo.lower(), len(com_lucro), "0", VERDE), ("Venda mediana em Portugal", med, EUR, ESCURO),
            ("Melhor lucro", bons[0][ch]["lucro"] if bons else None, EUR, VERDE), ("Carros portugueses comparados", d.get("nPT", 0), "0", ESCURO)]
    for i, (k, v, fm, cor) in enumerate(kpis):
        col = 2 + (i % 2) * 3; row = 4 + (i // 2) * 3
        f.set(row, col, k, E(cor=CINZA, tam=10, fundo=FUNDO, recuo=1)); f.set(row, col + 1, None, E(fundo=FUNDO))
        f.set(row + 1, col, v, E(negrito=True, tam=20, cor=cor, fundo=FUNDO, formato=fm, alinh="left", recuo=1)); f.set(row + 1, col + 1, None, E(fundo=FUNDO))
        f.fundir.append("%s%d:%s%d" % (_col(col), row, _col(col + 1), row)); f.fundir.append("%s%d:%s%d" % (_col(col), row + 1, _col(col + 1), row + 1))
        f.alturas[row + 1] = 32
    f.set(4, 8, "Anúncios por site", E(negrito=True))
    for i, (s, n) in enumerate(d.get("porSite", {}).items()): f.set(5 + i, 8, "%s: %d" % (s, n), E(cor=CINZA))

    r = 14
    f.set(r, 2, "10 melhores negócios (%s)" % nome_modo.lower(), E(negrito=True, tam=13, cor=ESCURO)); f.alturas[r] = 22
    cab = ["#", "Anúncio", "", "", "Compra", "Venda em PT", "Lucro", "Retorno"]
    hdr = E(negrito=True, cor="FFFFFF", fundo=AZUL); hdr_d = E(negrito=True, cor="FFFFFF", fundo=AZUL, alinh="right")
    for j, c in enumerate(cab, 1): f.set(r + 1, j, c or None, hdr_d if j >= 5 else hdr)
    f.fundir.append("B%d:D%d" % (r + 1, r + 1)); f.alturas[r + 1] = 22
    for i, a in enumerate(bons[:10], 1):
        rr = r + 1 + i; m = a[ch]; zebra = LISTA if i % 2 == 0 else None
        f.set(rr, 1, i, E(cor=CINZA, fundo=zebra, borda_baixo=LINHA, alinh="center"))
        f.set(rr, 2, "%s · %s · %s km · %s" % (a["titulo"], a["data"], km_txt(a["km"]), a["site"]), E(cor=AZUL, sublinhado=True, fundo=zebra, borda_baixo=LINHA))
        f.set(rr, 3, None, E(fundo=zebra, borda_baixo=LINHA)); f.set(rr, 4, None, E(fundo=zebra, borda_baixo=LINHA))
        f.link(rr, 2, a["url"]); f.fundir.append("B%d:D%d" % (rr, rr))
        f.set(rr, 5, a["preco"], E(formato=EUR, fundo=zebra, borda_baixo=LINHA))
        f.set(rr, 6, m["venda"], E(formato=EUR, fundo=zebra, borda_baixo=LINHA))
        f.set(rr, 7, m["lucro"], E(formato=EUR, negrito=True, cor=VERDE if m["lucro"] > 0 else VERMELHO, fundo=zebra, borda_baixo=LINHA))
        f.set(rr, 8, m["roi"], E(formato=PCT, fundo=zebra, borda_baixo=LINHA)); f.alturas[rr] = 20
    if not bons: f.set(r + 2, 2, "Sem anúncios com preço de referência em Portugal.", E(cor=CINZA, italico=True))
    nota = r + 13
    f.set(nota, 2, "Como ler: o “Lucro” já desconta compra, transporte, legalização, ISV, imprevistos, comissão do stand (ou IVA, se como stand) e garantia de 18 meses. "
                   "Na folha “Anúncios” estão todos os carros com as contas completas e filtros.", E(cor=CINZA, tam=9.5, italico=True, quebra=True, vertical="top"))
    f.fundir.append("B%d:H%d" % (nota, nota + 1)); f.alturas[nota] = 18; f.alturas[nota + 1] = 18

    # ======================= ANÚNCIOS =======================
    f = L.folha("Anúncios")
    cab = ["Site", "País", "Anúncio", "Registo", "Km", "Combustível", "Preço de compra", "ISV",
           "Consignação\ncusto total", "Consignação\nvenda em PT", "Consignação\nlucro", "Consignação\nretorno",
           "Stand\ncusto total", "Stand\nvenda em PT", "Stand\nlucro", "Stand\nretorno", "Situação", "Notas"]
    larg = [13, 7, 46, 10, 11, 13, 14, 11, 14, 14, 14, 12, 14, 14, 14, 12, 18, 46]
    for c, w in enumerate(larg, 1): f.larguras[c] = w
    titulo(f, "Todos os anúncios", "%s   |   %d anúncios   |   clique no nome para abrir o anúncio   |   use as setas dos cabeçalhos para filtrar" % (desc, len(anuncios)), len(cab))
    grupos = {9: "EAF1FC", 10: "EAF1FC", 11: "EAF1FC", 12: "EAF1FC", 13: "EEF0F3", 14: "EEF0F3", 15: "EEF0F3", 16: "EEF0F3"}
    for j, c in enumerate(cab, 1):
        f.set(4, j, c, E(negrito=True, cor="FFFFFF", fundo=AZUL if j < 9 or j > 16 else ("2A5DB0" if j <= 12 else "3C4652"), quebra=True, alinh="center" if j > 3 else None))
    f.alturas[4] = 36
    fmt = {5: KM, 7: EUR, 8: EUR, 9: EUR, 10: EUR, 11: EUR, 12: PCT, 13: EUR, 14: EUR, 15: EUR, 16: PCT}
    for i, a in enumerate(anuncios):
        rr = 5 + i; c, s = a["c"], a["s"]; sit = situacao(a[ch])
        notas = []
        if a.get("danosNivel") in ("grave", "reparado", "aviso") or a.get("danos", "").startswith("✓"): notas.append(a["danos"])
        if a.get("regimeIVA"): notas.append(a["regimeIVA"])
        if a.get("suspeito"): notas.append("⚠ Preço muito abaixo dos outros: confirmar versão e estado")
        if a.get("isvEstimado"): notas.append("ISV estimado (%s não indicado)" % a["isvEstimado"])
        if a.get("isv") is None: notas.append("ISV por calcular: faltam dados")
        vals = [a["site"], a["pais"], a["titulo"], a["data"], a["km"], a["combustivel"], a["preco"], a.get("isv"),
                c["total"], c["venda"], c["lucro"], c["roi"], s["total"], s["venda"], s["lucro"], s["roi"], sit, "; ".join(notas)]
        zebra = LISTA if i % 2 else None
        for j, v in enumerate(vals, 1):
            kw = dict(formato=fmt.get(j), fundo=grupos.get(j) if zebra is None and j in grupos else zebra, borda_baixo=LINHA)
            if j == 3: kw.update(cor=AZUL, sublinhado=True)
            if j in (11, 15) and v is not None: kw.update(negrito=True, cor=VERDE if v > 0 else VERMELHO, fundo=VERDE_F if v > 0 else VERM_F)
            if j == 17: kw.update(negrito=True, cor={"Bom negócio": VERDE, "Prejuízo": VERMELHO, "Margem curta": AMBAR}.get(v, CINZA),
                                  fundo={"Bom negócio": VERDE_F, "Prejuízo": VERM_F, "Margem curta": AMBAR_F}.get(v, zebra))
            if j == 18: kw.update(cor=VERMELHO if a.get("danosNivel") in ("grave", "reparado") else AMBAR if (a.get("danosNivel") == "aviso" or a.get("suspeito")) else VERDE if a.get("danosNivel") == "ok" else CINZA, tam=10, negrito=a.get("danosNivel") in ("grave", "reparado"))
            f.set(rr, j, v, E(**kw))
        f.link(rr, 3, a["url"]); f.alturas[rr] = 19
    fim = 4 + max(1, len(anuncios))
    f.filtro = "A4:%s%d" % (_col(len(cab)), fim); f.congelar = (5, 4)

    # ======================= PREÇOS EM PORTUGAL =======================
    f = L.folha("Preços em Portugal"); pt = d.get("pt", [])
    for c, w in enumerate([56, 8, 12, 14, 13, 14], 1): f.larguras[c] = w
    titulo(f, "Carros parecidos à venda em Portugal", "Fonte: Standvirtual (só como referência do preço de venda)   |   %d anúncios" % len(pt), 6)
    for j, c in enumerate(["Anúncio", "Ano", "Km", "Vendedor", "Preço", "Combustível"], 1): f.set(4, j, c, E(negrito=True, cor="FFFFFF", fundo=AZUL))
    f.alturas[4] = 22
    for i, x in enumerate(pt):
        rr = 5 + i; z = LISTA if i % 2 else None
        for j, (v, fm) in enumerate([(x["titulo"], None), (x["ano"], "0"), (x["km"], KM), (x["vendedor"], None), (x["preco"], EUR), (x["combustivel"], None)], 1):
            f.set(rr, j, v, E(formato=fm, fundo=z, borda_baixo=LINHA, cor=AZUL if j == 1 else None, sublinhado=j == 1))
        f.link(rr, 1, x["url"])
    f.filtro = "A4:F%d" % (4 + max(1, len(pt))); f.congelar = (5, 1)

    # ======================= PRESSUPOSTOS =======================
    f = L.folha("Pressupostos")
    for c, w in enumerate([28, 52, 14], 1): f.larguras[c] = w
    titulo(f, "Pressupostos usados nas contas", "Pode alterá-los no programa em “Ajustar custos, comissões e impostos”", 3)
    for j, c in enumerate(["Grupo", "Parâmetro", "Valor"], 1): f.set(4, j, c, E(negrito=True, cor="FFFFFF", fundo=AZUL))
    ps = d.get("pressupostos", [])
    for i, p in enumerate(ps):
        z = LISTA if i % 2 else None
        f.set(5 + i, 1, p["grupo"], E(cor=CINZA, fundo=z, borda_baixo=LINHA)); f.set(5 + i, 2, p["nome"], E(fundo=z, borda_baixo=LINHA))
        f.set(5 + i, 3, p["valor"], E(fundo=z, borda_baixo=LINHA, formato="#,##0.##"))
    regras = ["ISV 2026: cilindrada + CO₂ (WLTP; NEDC para carros anteriores a 2019), com a redução por idade da Tabela D; mínimo 100 €. Sem CO₂ no anúncio: estimado pela potência.",
              "Venda em Portugal: mediana de pelo menos 3 carros parecidos (mesmo combustível, ano ±1 ou ±2, km próximos). Preços de stands descem para equivaler a particular; tira-se o desconto de negociação.",
              "Consignação: venda − comissão − garantia de 18 meses − custo total. Como stand: IVA sobre a margem (ou 23% sobre a venda se o IVA da compra for dedutível)."]
    r0 = 6 + len(ps)
    for i, t in enumerate(regras):
        f.set(r0 + i, 1, "• " + t, E(cor=CINZA, tam=10, quebra=True, vertical="top")); f.fundir.append("A%d:C%d" % (r0 + i, r0 + i)); f.alturas[r0 + i] = 32
    L.guardar(caminho)
