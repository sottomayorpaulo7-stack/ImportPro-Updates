# Atualizações automáticas do ImportPro.
# O programa lê um pequeno ficheiro na internet (manifesto) com a versão mais recente:
#   {"versao": "2026.11.20-1", "pacote": "https://.../importpro.zip", "sha256": "…", "notas": "O que mudou"}
# Se for mais recente do que a instalada, descarrega o pacote, confirma a impressão digital (sha256),
# guarda uma cópia da versão atual em "versao_anterior" e substitui os ficheiros do programa.
# A chave do Firecrawl (config.json), os favoritos e os ajustes nunca são tocados.
import hashlib, io, json, os, re, shutil, time, urllib.request, zipfile

PERMITIDOS = {"servidor.py", "index.html", "importpro.ico", "instalar.ps1", "relatorio.py",
              "xlsx_simples.py", "isv_oficial.py", "iuc_oficial.py", "atualizar.py"}

def num(v):
    """'2026.11.13-12' -> (2026, 11, 13, 12), para comparar versões corretamente."""
    return tuple(int(x) for x in re.findall(r"\d+", str(v or "")))

def _get(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": "ImportPro", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()

def verificar(url_manifesto, versao_atual):
    if not url_manifesto:
        return {"ativo": False}
    m = json.loads(_get(url_manifesto + ("&" if "?" in url_manifesto else "?") + "t=%d" % time.time()).decode("utf-8"))
    nova = num(m.get("versao")) > num(versao_atual)
    return {"ativo": True, "nova": nova, "versao": m.get("versao"), "notas": m.get("notas", ""),
            "pacote": m.get("pacote"), "sha256": (m.get("sha256") or "").lower()}

def aplicar(pasta, info):
    dados = _get(info["pacote"], timeout=120)
    if not info.get("sha256") or hashlib.sha256(dados).hexdigest() != info["sha256"]:
        raise ValueError("o pacote descarregado não corresponde à impressão digital publicada")
    z = zipfile.ZipFile(io.BytesIO(dados))
    nomes = [n for n in z.namelist() if not n.endswith("/")]
    if not nomes or any(os.path.basename(n) != n or n not in PERMITIDOS for n in nomes):
        raise ValueError("o pacote tem ficheiros inesperados")
    if "servidor.py" not in nomes or "index.html" not in nomes:
        raise ValueError("o pacote está incompleto")
    # cópia de segurança da versão atual
    copia = os.path.join(pasta, "versao_anterior"); os.makedirs(copia, exist_ok=True)
    for n in PERMITIDOS:
        f = os.path.join(pasta, n)
        if os.path.exists(f): shutil.copy2(f, os.path.join(copia, n))
    # escreve cada ficheiro novo de forma segura (primeiro .novo, depois troca)
    for n in nomes:
        destino = os.path.join(pasta, n)
        with open(destino + ".novo", "wb") as f: f.write(z.read(n))
        os.replace(destino + ".novo", destino)
    with open(os.path.join(pasta, "atualizado.json"), "w", encoding="utf-8") as f:
        json.dump({"versao": info["versao"], "notas": info.get("notas", ""), "em": time.strftime("%Y-%m-%d %H:%M")}, f, ensure_ascii=False)
    return True

def publicar(pasta_ficheiros, versao, notas, url_pacote, destino_zip, destino_manifesto):
    """Usado por quem faz a versão nova: cria o pacote e o manifesto a publicar."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(PERMITIDOS):
            f = os.path.join(pasta_ficheiros, n)
            if os.path.exists(f): z.write(f, n)
    dados = buf.getvalue()
    with open(destino_zip, "wb") as f: f.write(dados)
    m = {"versao": versao, "pacote": url_pacote, "sha256": hashlib.sha256(dados).hexdigest(), "notas": notas}
    with open(destino_manifesto, "w", encoding="utf-8") as f: json.dump(m, f, ensure_ascii=False, indent=1)
    return m
