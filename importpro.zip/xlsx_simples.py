# Escritor de ficheiros .xlsx só com a biblioteca padrão do Python (sem instalar nada)
import zipfile, datetime
from xml.sax.saxutils import escape

def _col(n):
    s = ""
    while n: n, r = divmod(n - 1, 26); s = chr(65 + r) + s
    return s

def _xml(t):
    t = "".join(ch for ch in str(t) if ch in "\t\n\r" or ord(ch) >= 32)
    return escape(t, {'"': "&quot;"})

class Estilos:
    def __init__(self):
        self.fontes = ['<font><sz val="11"/><name val="Calibri"/></font>']
        self.fundos = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>']
        self.bordas = ['<border><left/><right/><top/><bottom/><diagonal/></border>']
        self.formatos = {}
        self.xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>']
        self.cache = {}
    def _idx(self, lista, x):
        if x not in lista: lista.append(x)
        return lista.index(x)
    def get(self, negrito=False, cor=None, tam=11, italico=False, sublinhado=False, fundo=None, formato=None,
            alinh=None, quebra=False, vertical="center", borda_baixo=None, recuo=0):
        k = (negrito, cor, tam, italico, sublinhado, fundo, formato, alinh, quebra, vertical, borda_baixo, recuo)
        if k in self.cache: return self.cache[k]
        f = "<font>%s%s%s<sz val=\"%s\"/>%s<name val=\"Calibri\"/></font>" % (
            "<b/>" if negrito else "", "<i/>" if italico else "", "<u/>" if sublinhado else "", tam,
            '<color rgb="FF%s"/>' % cor if cor else "")
        fi = self._idx(self.fontes, f)
        fu = self._idx(self.fundos, '<fill><patternFill patternType="solid"><fgColor rgb="FF%s"/><bgColor indexed="64"/></patternFill></fill>' % fundo) if fundo else 0
        bo = self._idx(self.bordas, '<border><left/><right/><top/><bottom style="thin"><color rgb="FF%s"/></bottom><diagonal/></border>' % borda_baixo) if borda_baixo else 0
        nf = 0
        if formato:
            if formato not in self.formatos: self.formatos[formato] = 164 + len(self.formatos)
            nf = self.formatos[formato]
        al = '<alignment vertical="%s"%s%s%s/>' % (vertical, ' horizontal="%s"' % alinh if alinh else "",
                                                   ' wrapText="1"' if quebra else "", ' indent="%d"' % recuo if recuo else "")
        xf = '<xf numFmtId="%d" fontId="%d" fillId="%d" borderId="%d" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyNumberFormat="1" applyAlignment="1">%s</xf>' % (nf, fi, fu, bo, al)
        self.xfs.append(xf); self.cache[k] = len(self.xfs) - 1
        return self.cache[k]
    def xml(self):
        nf = "".join('<numFmt numFmtId="%d" formatCode="%s"/>' % (i, _xml(f)) for f, i in self.formatos.items())
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                '<numFmts count="%d">%s</numFmts><fonts count="%d">%s</fonts><fills count="%d">%s</fills><borders count="%d">%s</borders>'
                '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="%d">%s</cellXfs>'
                '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>') % (
            len(self.formatos), nf, len(self.fontes), "".join(self.fontes), len(self.fundos), "".join(self.fundos),
            len(self.bordas), "".join(self.bordas), len(self.xfs), "".join(self.xfs))

class Folha:
    def __init__(self, nome):
        self.nome = nome[:31]; self.celulas = {}; self.larguras = {}; self.alturas = {}; self.fundir = []
        self.links = []; self.congelar = None; self.filtro = None; self.grelha = False
    def set(self, r, c, v, estilo=0): self.celulas[(r, c)] = (v, estilo)
    def link(self, r, c, url): self.links.append((r, c, url))
    def xml(self):
        linhas = {}
        for (r, c), x in self.celulas.items(): linhas.setdefault(r, {})[c] = x
        out = []
        for r in sorted(set(linhas) | set(self.alturas)):
            alt = ' ht="%s" customHeight="1"' % self.alturas[r] if r in self.alturas else ""
            cel = []
            for c in sorted(linhas.get(r, {})):
                v, s = linhas[r][c]; ref = "%s%d" % (_col(c), r)
                if v is None or v == "": cel.append('<c r="%s" s="%d"/>' % (ref, s))
                elif isinstance(v, bool): cel.append('<c r="%s" s="%d" t="b"><v>%d</v></c>' % (ref, s, v))
                elif isinstance(v, (int, float)): cel.append('<c r="%s" s="%d"><v>%s</v></c>' % (ref, s, repr(float(v)) if isinstance(v, float) else v))
                else: cel.append('<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, s, _xml(v)))
            out.append('<row r="%d"%s>%s</row>' % (r, alt, "".join(cel)))
        vista = '<sheetView workbookViewId="0"%s>' % ('' if self.grelha else ' showGridLines="0"')
        if self.congelar:
            r, c = self.congelar; ref = "%s%d" % (_col(c), r)
            pane = "bottomRight" if (r > 1 and c > 1) else ("bottomLeft" if r > 1 else "topRight")
            vista += '<pane %s%stopLeftCell="%s" activePane="%s" state="frozen"/><selection pane="%s" activeCell="%s" sqref="%s"/>' % (
                'xSplit="%d" ' % (c - 1) if c > 1 else "", 'ySplit="%d" ' % (r - 1) if r > 1 else "", ref, pane, pane, ref, ref)
        vista += "</sheetView>"
        cols = "".join('<col min="%d" max="%d" width="%s" customWidth="1"/>' % (c, c, w) for c, w in sorted(self.larguras.items()))
        x = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
             'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews>%s</sheetViews>'
             '<sheetFormatPr defaultRowHeight="15"/>%s<sheetData>%s</sheetData>') % (vista, "<cols>%s</cols>" % cols if cols else "", "".join(out))
        if self.filtro: x += '<autoFilter ref="%s"/>' % self.filtro
        if self.fundir: x += '<mergeCells count="%d">%s</mergeCells>' % (len(self.fundir), "".join('<mergeCell ref="%s"/>' % m for m in self.fundir))
        if self.links: x += "<hyperlinks>%s</hyperlinks>" % "".join('<hyperlink ref="%s%d" r:id="rId%d"/>' % (_col(c), r, i + 1) for i, (r, c, u) in enumerate(self.links))
        x += '<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>'
        return x
    def rels(self):
        return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">%s</Relationships>' %
                "".join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="%s" TargetMode="External"/>' % (i + 1, _xml(u)) for i, (r, c, u) in enumerate(self.links)))

class Livro:
    def __init__(self): self.folhas = []; self.estilos = Estilos()
    def folha(self, nome): f = Folha(nome); self.folhas.append(f); return f
    def guardar(self, caminho):
        n = len(self.folhas)
        with zipfile.ZipFile(caminho, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                       '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
                       '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                       '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
                       '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
                       + "".join('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1) for i in range(n)) + "</Types>")
            z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                       '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                       '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>')
            agora = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
            z.writestr("docProps/core.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
                       'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
                       '<dc:title>Importa Console</dc:title><dc:creator>Importa Console</dc:creator>'
                       '<dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created></cp:coreProperties>' % agora)
            nomes = []
            for i, f in enumerate(self.folhas):
                nomes.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (_xml(f.nome), i + 1, i + 1))
                z.writestr("xl/worksheets/sheet%d.xml" % (i + 1), f.xml())
                if f.links: z.writestr("xl/worksheets/_rels/sheet%d.xml.rels" % (i + 1), f.rels())
            import re
            abs_ = lambda ref: re.sub(r"([A-Z]+)(\d+)", r"$\1$\2", ref)
            defs = "".join('<definedName name="_xlnm._FilterDatabase" localSheetId="%d" hidden="1">\'%s\'!%s</definedName>' % (
                i, _xml(f.nome.replace("'", "''")), abs_(f.filtro)) for i, f in enumerate(self.folhas) if f.filtro)
            z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                       'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><workbookPr/><bookViews><workbookView/></bookViews><sheets>%s</sheets>%s</workbook>' % (
                           "".join(nomes), "<definedNames>%s</definedNames>" % defs if defs else ""))
            z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                       + "".join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1) for i in range(n))
                       + '<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % (n + 1))
            z.writestr("xl/styles.xml", self.estilos.xml())
