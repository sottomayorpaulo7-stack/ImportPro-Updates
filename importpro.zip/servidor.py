# ImportPro - servidor local (so usa a biblioteca padrao do Python)
import json, os, sys, time, threading, socket, subprocess, webbrowser, urllib.request, urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

VERSAO = "2026.11.13-5"
# endereço do manifesto das atualizações automáticas (fica vazio até haver onde publicar as versões)
# (vários endereços separados por espaços: usa o primeiro que responder)
URL_ATUALIZACOES = os.environ.get("IMPORTA_ATUALIZACOES", "https://raw.githubusercontent.com/ImportPro-PT/ImportPro-Updates/main/versao.json "
                                  "https://raw.githubusercontent.com/sottomayorpaulo7-stack/ImportPro-Updates/main/versao.json")
ATUAL = {}
PORTA = 8766
PASTA = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(PASTA, "config.json")
URL = "http://127.0.0.1:%d/" % PORTA
API = os.environ.get("IMPORTA_API", "https://api.firecrawl.dev")
ultimo_sinal = time.time()
ativos = 0
trinco = threading.Lock()

def ler_config():
    try:
        with open(CONFIG, encoding="utf-8") as f: return json.load(f)
    except Exception: return {}

def gravar_config(c):
    with open(CONFIG, "w", encoding="utf-8") as f: json.dump(c, f)

def firecrawl_md(url, opcoes, chave):
    """Pede ao Firecrawl o texto (markdown) de uma página ou PDF."""
    corpo = dict(opcoes); corpo["url"] = url
    for versao in ("v2", "v1"):
        pedido = urllib.request.Request("%s/%s/scrape" % (API, versao), data=json.dumps(corpo).encode(), method="POST",
            headers={"Authorization": "Bearer " + chave, "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(pedido, timeout=180) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
            md = (d.get("data") or {}).get("markdown")
            if md: return md
            raise RuntimeError(d.get("error") or "sem texto")
        except urllib.error.HTTPError as e:
            if e.code == 404 and versao == "v2": continue
            try: msg = json.loads(e.read().decode("utf-8", "replace")).get("error") or ""
            except Exception: msg = ""
            if e.code == 400 and corpo.get("parsers") != ["pdf"]:   # opções não aceites: tenta a forma simples
                corpo["parsers"] = ["pdf"]; corpo.pop("pdfOptions", None)
                return firecrawl_md(url, corpo, chave)
            raise RuntimeError(("HTTP %d %s" % (e.code, msg)).strip())

def creditos(chave):
    """Créditos que restam na conta Firecrawl desta chave. Devolve dict; levanta RuntimeError("CHAVE") se a chave for inválida."""
    for versao in ("v2", "v1"):
        pedido = urllib.request.Request("%s/%s/team/credit-usage" % (API, versao), headers={"Authorization": "Bearer " + chave})
        try:
            with urllib.request.urlopen(pedido, timeout=20) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            if e.code == 404 and versao == "v2": continue
            if e.code in (401, 403): raise RuntimeError("CHAVE")
            raise RuntimeError("HTTP %d" % e.code)
        x = d.get("data") or {}
        rest = x.get("remainingCredits", x.get("remaining_credits"))
        if rest is None: raise RuntimeError(d.get("error") or "sem dados")
        info = {"restantes": rest, "plano": x.get("planCredits", x.get("plan_credits")), "fim": x.get("billingPeriodEnd", x.get("billing_period_end"))}
        try:   # pedidos em simultâneo do plano (opcional)
            p2 = urllib.request.Request("%s/v2/team/queue-status" % API, headers={"Authorization": "Bearer " + chave})
            with urllib.request.urlopen(p2, timeout=10) as r2:
                qd = json.loads(r2.read().decode("utf-8", "replace"))
            info["simultaneos"] = qd.get("maxConcurrency")
        except Exception: pass
        return info
    raise RuntimeError("sem dados")

ISV = {"a_verificar": False}
def verificar_isv():
    """Confirma nas Finanças as tabelas do ISV e do IUC. Só termina (a_verificar=False) quando as duas estão verificadas."""
    global ISV
    chave = ler_config().get("chave")
    if ISV.get("a_verificar") and ISV.get("_corre"): return
    ISV = dict(ISV, a_verificar=True, _corre=True)
    fc = lambda url, op: firecrawl_md(url, op, chave)
    sys.path.insert(0, PASTA)
    res = {}
    def isv():
        try:
            import isv_oficial
            res["isv"] = isv_oficial.verificar(PASTA, chave, fc)
        except Exception as e:
            res["isv"] = {"erro": "Verificação das tabelas de ISV falhou: %s" % e}
    def iuc():
        try:
            import iuc_oficial
            res["iuc"] = iuc_oficial.verificar(PASTA, chave, fc)
        except Exception as e:
            res["iuc"] = {"erro": "Verificação das tabelas do IUC falhou: %s" % e}
    fios = [threading.Thread(target=isv, daemon=True), threading.Thread(target=iuc, daemon=True)]   # as duas ao mesmo tempo
    for t in fios: t.start()
    for t in fios: t.join()
    novo = res["isv"]; novo["iuc"] = res["iuc"]
    novo["a_verificar"] = False
    ISV = novo
    for nome, x in (("ISV", novo), ("IUC", novo.get("iuc") or {})):
        if x.get("erro"):
            try:
                with open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8") as h: h.write(time.strftime("%Y-%m-%d %H:%M ") + nome + ": " + str(x["erro"]) + "\n")
            except Exception: pass

def firecrawl(url, chave):
    """Pede a pagina ao Firecrawl. Devolve (html, None) ou (None, mensagem)."""
    corpo = json.dumps({"url": url, "formats": ["rawHtml"], "onlyMainContent": False}).encode()
    ultimo = "erro desconhecido"
    for tentativa in range(6):
        for versao in ("v2", "v1"):
            pedido = urllib.request.Request("%s/%s/scrape" % (API, versao), data=corpo, method="POST",
                headers={"Authorization": "Bearer " + chave, "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(pedido, timeout=150) as r:
                    d = json.loads(r.read().decode("utf-8", "replace"))
                h = (d.get("data") or {}).get("rawHtml")
                if h: return h, None
                ultimo = d.get("error") or "o Firecrawl nao devolveu a pagina"
                break
            except urllib.error.HTTPError as e:
                try: msg = json.loads(e.read().decode("utf-8", "replace")).get("error", "")
                except Exception: msg = ""
                if e.code == 404 and versao == "v2": continue          # API antiga: tenta v1
                if e.code == 401: return None, "CHAVE"                 # chave errada
                if e.code == 402: return None, "CREDITOS"              # sem creditos
                ultimo = "HTTP %d %s" % (e.code, msg)
                if e.code == 429:                                     # demasiados pedidos ao mesmo tempo
                    try: espera = float(e.headers.get("Retry-After") or 0)
                    except Exception: espera = 0
                    time.sleep(min(30, max(espera, 5 + 5 * tentativa)))
                elif e.code < 500: return None, ultimo
                break
            except Exception as e:
                ultimo = str(e); break
        time.sleep(1.5 * (tentativa + 1))
    return None, ultimo

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def enviar(self, codigo, obj, tipo="application/json; charset=utf-8"):
        dados = obj if isinstance(obj, bytes) else json.dumps(obj).encode()
        self.send_response(codigo); self.send_header("Content-Type", tipo)
        self.send_header("Cache-Control", "no-store"); self.send_header("Content-Length", str(len(dados)))
        self.end_headers(); self.wfile.write(dados)
    def corpo(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")
    def do_GET(self):
        global ultimo_sinal
        ultimo_sinal = time.time()
        if self.path in ("/", "/index.html"):
            with open(os.path.join(PASTA, "index.html"), "rb") as f:
                return self.enviar(200, f.read(), "text/html; charset=utf-8")
        if self.path == "/api/estado":
            ch = ler_config().get("chave") or ""
            return self.enviar(200, {"chave": bool(ch), "fim": ch[-4:] if ch else "", "versao": VERSAO})
        if self.path == "/api/creditos":
            ch = ler_config().get("chave")
            if not ch: return self.enviar(200, {"erro": "SEMCHAVE"})
            conta = ler_config().get("conta", "")
            try: return self.enviar(200, dict(creditos(ch), conta=conta))
            except Exception as e: return self.enviar(200, {"erro": str(e), "conta": conta})
        if self.path == "/api/isv":
            return self.enviar(200, ISV)
        if self.path == "/api/atualizacao":
            r = {k: v for k, v in ATUAL.items() if k not in ("pacote", "sha256")}
            try:   # acabou de ser atualizado? mostra uma vez o que mudou
                fic = os.path.join(PASTA, "atualizado.json")
                with open(fic, encoding="utf-8") as h: feito = json.load(h)
                if feito.get("versao") == VERSAO: r["feito"] = feito
                os.remove(fic)
            except Exception: pass
            return self.enviar(200, r)
        if self.path == "/api/favoritos":
            try:
                with open(os.path.join(PASTA, "favoritos.json"), encoding="utf-8") as f: return self.enviar(200, {"lista": json.load(f)})
            except Exception: return self.enviar(200, {"lista": []})
        if self.path == "/api/vivo":
            return self.enviar(200, {"ok": True})
        self.enviar(404, {"erro": "nao existe"})
    def do_POST(self):
        global ultimo_sinal, ativos
        ultimo_sinal = time.time()
        if self.path == "/api/chave":
            corpo = self.corpo()
            if corpo.get("remover"):
                c = ler_config(); c.pop("chave", None); c.pop("conta", None); gravar_config(c)
                return self.enviar(200, {"ok": True})
            if "conta" in corpo and not corpo.get("chave"):
                c = ler_config(); c["conta"] = str(corpo.get("conta", "")).strip()[:120]; gravar_config(c)
                return self.enviar(200, {"ok": True})
            chave = str(corpo.get("chave", "")).strip()
            if not chave.startswith("fc-"): return self.enviar(400, {"erro": "A chave do Firecrawl começa por fc-"})
            info = None
            try: info = creditos(chave)
            except RuntimeError as e:
                if str(e) == "CHAVE": return self.enviar(400, {"erro": "O Firecrawl não aceitou esta chave. Confirme que a copiou inteira."})
            except Exception: pass   # sem ligação: guarda na mesma
            c = ler_config(); c["chave"] = chave; c["conta"] = str(corpo.get("conta", "")).strip()[:120]; gravar_config(c)
            threading.Thread(target=verificar_isv, daemon=True).start()
            return self.enviar(200, {"ok": True, "creditos": info})
        if self.path == "/api/atualizar":
            if not ATUAL.get("nova"): return self.enviar(400, {"erro": "não há versão nova"})
            try:
                import atualizar
                atualizar.aplicar(PASTA, ATUAL)
            except Exception as e:
                registar("Atualização falhou: %s" % e)
                return self.enviar(500, {"erro": "Não consegui atualizar: %s" % e})
            threading.Timer(0.8, reiniciar).start()
            return self.enviar(200, {"ok": True, "versao": ATUAL.get("versao")})
        if self.path == "/api/favoritos":
            lista = self.corpo().get("lista")
            if not isinstance(lista, list): return self.enviar(400, {"erro": "lista inválida"})
            fic = os.path.join(PASTA, "favoritos.json")
            with open(fic + ".tmp", "w", encoding="utf-8") as f: json.dump(lista, f, ensure_ascii=False)
            os.replace(fic + ".tmp", fic)
            return self.enviar(200, {"ok": True})
        if self.path == "/api/isv":
            threading.Thread(target=verificar_isv, daemon=True).start()
            return self.enviar(200, {"ok": True})
        if self.path == "/api/excel":
            try: caminho = gerar_excel(self.corpo())
            except Exception as e:
                import traceback
                try:
                    with open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8") as f: f.write(traceback.format_exc())
                except Exception: pass
                return self.enviar(500, {"erro": "%s: %s" % (type(e).__name__, e)})
            return self.enviar(200, {"ficheiro": caminho})
        if self.path == "/api/scrape":
            chave = ler_config().get("chave")
            if not chave: return self.enviar(400, {"erro": "CHAVE"})
            url = str(self.corpo().get("url", ""))
            with trinco: ativos += 1
            try: html, erro = firecrawl(url, chave)
            finally:
                with trinco: ativos -= 1
                ultimo_sinal = time.time()
            if html: return self.enviar(200, {"rawHtml": html})
            return self.enviar(502, {"erro": erro})
        self.enviar(404, {"erro": "nao existe"})

def pasta_transferencias():
    try:   # pasta "Transferências" verdadeira do Windows (mesmo se estiver no OneDrive)
        import ctypes, uuid
        from ctypes import wintypes
        guid = uuid.UUID("{374DE290-123F-4565-9164-39C4925E467B}")
        class GUID(ctypes.Structure):
            _fields_ = [("a", wintypes.DWORD), ("b", wintypes.WORD), ("c", wintypes.WORD), ("d", ctypes.c_ubyte * 8)]
        g = GUID(guid.fields[0], guid.fields[1], guid.fields[2], (ctypes.c_ubyte * 8)(*guid.bytes[8:]))
        p = ctypes.c_wchar_p()
        if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(g), 0, None, ctypes.byref(p)) == 0 and os.path.isdir(p.value):
            return p.value
    except Exception: pass
    for p in (os.path.join(os.path.expanduser("~"), "Downloads"), os.path.expanduser("~")):
        if os.path.isdir(p): return p
    return PASTA

def gerar_excel(d):
    sys.path.insert(0, PASTA)
    import relatorio
    pasta = pasta_transferencias()
    c = d.get("criterios", {})
    nome = "ImportPro %s %s %s.xlsx" % (c.get("marca", ""), c.get("modelo", ""), time.strftime("%Y-%m-%d %Hh%M %Ss"))
    nome = "".join(ch for ch in nome if ch not in '\\/:*?"<>|')
    caminho = os.path.join(pasta, nome)
    relatorio.gerar(d, caminho)
    try: os.startfile(caminho)          # abre no Excel (Windows)
    except Exception: pass
    return caminho

def abrir_janela():
    for p in (r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe", r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe",
              r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe", r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
              r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe", r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"):
        p = os.path.expandvars(p)
        if os.path.exists(p):
            try:
                subprocess.Popen([p, "--app=" + URL, "--window-size=1400,900"]); return
            except Exception: pass
    webbrowser.open(URL)

def registar(msg):
    try:
        with open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8") as f: f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except Exception: pass

def procurar_atualizacao():
    global ATUAL
    try:
        sys.path.insert(0, PASTA)
        import atualizar
        ATUAL = atualizar.verificar(URL_ATUALIZACOES, VERSAO)
    except Exception as e:
        ATUAL = {"ativo": bool(URL_ATUALIZACOES), "erro": str(e)}

def reiniciar():
    # arranca o programa novo (já atualizado) e fecha este; a janela recarrega sozinha
    env = dict(os.environ, IMPORTA_SEM_JANELA="1", IMPORTA_REINICIO="1")
    try: srv.server_close()
    except Exception: pass
    flags = 0x08000000 if os.name == "nt" else 0          # CREATE_NO_WINDOW
    subprocess.Popen([sys.executable, os.path.join(PASTA, "servidor.py")], env=env, cwd=PASTA, creationflags=flags)
    os._exit(0)

def vigiar():
    # fecha o servidor quando a janela da calculadora esta fechada ha 3 minutos
    while True:
        time.sleep(20)
        if ativos == 0 and time.time() - ultimo_sinal > 180: os._exit(0)

class Servidor(ThreadingHTTPServer):
    daemon_threads = True
    def handle_error(self, request, client_address):
        try:
            import traceback
            with open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + traceback.format_exc() + "\n")
        except Exception: pass

if __name__ == "__main__":
    if sys.stderr is None or sys.stdout is None:          # pythonw: sem consola
        try:
            sys.stderr = sys.stdout = open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8")
        except Exception: pass
    reinicio = bool(os.environ.pop("IMPORTA_REINICIO", ""))
    if not reinicio:
        s = socket.socket(); s.settimeout(1)
        a_correr = s.connect_ex(("127.0.0.1", PORTA)) == 0; s.close()
        if a_correr:
            abrir_janela(); sys.exit(0)        # ja esta a correr: so abre a janela
    srv = None
    for _ in range(40):                        # depois de uma atualização, espera que o programa antigo liberte a porta
        try: srv = Servidor(("127.0.0.1", PORTA), H); break
        except OSError:
            if not reinicio: raise
            time.sleep(0.25)
    if srv is None: sys.exit(1)
    threading.Thread(target=procurar_atualizacao, daemon=True).start()
    threading.Thread(target=vigiar, daemon=True).start()
    try:
        with open(os.path.join(PASTA, "isv.json"), encoding="utf-8") as h: ISV = dict(json.load(h), a_verificar=True)
        try:
            with open(os.path.join(PASTA, "iuc.json"), encoding="utf-8") as h: ISV["iuc"] = json.load(h)
        except Exception: pass
    except Exception: pass
    threading.Thread(target=verificar_isv, daemon=True).start()
    if not os.environ.get("IMPORTA_SEM_JANELA"): threading.Timer(0.6, abrir_janela).start()
    srv.serve_forever()
