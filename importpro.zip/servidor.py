# ImportPro - servidor local (so usa a biblioteca padrao do Python)
import json, os, sys, time, threading, socket, subprocess, webbrowser, urllib.request, urllib.error
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

VERSAO = "2026.11.13-9"
# endereço do manifesto das atualizações automáticas (fica vazio até haver onde publicar as versões)
# (vários endereços separados por espaços: usa o primeiro que responder)
URL_ATUALIZACOES = os.environ.get("IMPORTA_ATUALIZACOES", "https://raw.githubusercontent.com/ImportPro-PT/ImportPro-Updates/main/versao.json "
                                  "https://raw.githubusercontent.com/sottomayorpaulo7-stack/ImportPro-Updates/main/versao.json")
ATUAL = {}
ATUAL_EM = 0

# >>> conta.py (gerado por build.py, não editar aqui)
CONTA_PY = '# Contas de utilizador do ImportPro (registo, entrada, perfil), através do Supabase Auth.\n# A sessão fica guardada só neste computador, em sessao.json (nunca vai para o instalador nem para as atualizações).\nimport json, os, time, urllib.request, urllib.error, urllib.parse\n\nSUPABASE = os.environ.get("IMPORTA_SUPABASE", "https://lyqmalwznymzwrzikbyn.supabase.co")\nCHAVE_PUBLICA = "sb_publishable_VrgNxXMTCF3hFwyJ19BzpA_0d2w95np"   # chave pública (pode estar no programa)\nVOLTAR = "http://127.0.0.1:8766/"                                  # para onde voltam os links dos emails\nOFFLINE_DIAS = 7                                                   # sem internet, a sessão vale 7 dias\n\nclass Erro(Exception):\n    def __init__(self, msg, codigo=400):\n        super().__init__(msg); self.msg = msg; self.codigo = codigo\n\nMENSAGENS = {\n    "invalid_credentials": "Email ou palavra-passe errados.",\n    "email_not_confirmed": "Ainda não confirmou o email. Abra o email que lhe enviámos e carregue no link.",\n    "user_already_exists": "Já existe uma conta com este email. Use “Entrar” ou “Esqueci-me da palavra-passe”.",\n    "email_exists": "Já existe uma conta com este email. Use “Entrar” ou “Esqueci-me da palavra-passe”.",\n    "weak_password": "A palavra-passe é demasiado fraca. Use pelo menos 8 caracteres, com letras e números.",\n    "email_address_invalid": "O email não é válido.",\n    "email_address_not_authorized": "Ainda não é possível enviar emails para este endereço (o envio de emails está em configuração).",\n    "over_email_send_rate_limit": "Foram enviados demasiados emails. Espere uns minutos e tente de novo.",\n    "over_request_rate_limit": "Demasiadas tentativas. Espere uns minutos e tente de novo.",\n    "same_password": "A palavra-passe nova tem de ser diferente da atual.",\n    "session_not_found": "A sessão terminou. Entre outra vez.",\n    "user_not_found": "A conta já não existe.",\n}\n\ndef _pedido(metodo, caminho, corpo=None, token=None, extra=None):\n    h = {"apikey": CHAVE_PUBLICA, "Content-Type": "application/json", "Accept": "application/json"}\n    if token: h["Authorization"] = "Bearer " + token\n    if extra: h.update(extra)\n    dados = json.dumps(corpo).encode() if corpo is not None else None\n    req = urllib.request.Request(SUPABASE + caminho, data=dados, headers=h, method=metodo)\n    try:\n        with urllib.request.urlopen(req, timeout=20) as r:\n            t = r.read().decode() or "null"\n            return json.loads(t)\n    except urllib.error.HTTPError as e:\n        try: d = json.loads(e.read().decode() or "{}")\n        except Exception: d = {}\n        cod = d.get("error_code") or d.get("code") or d.get("error") or ""\n        msg = MENSAGENS.get(cod) or d.get("msg") or d.get("message") or d.get("error_description") or ("Erro %s" % e.code)\n        if cod == "weak_password" or "password" in str(msg).lower() and "least" in str(msg).lower():\n            msg = MENSAGENS["weak_password"]\n        raise Erro(msg, e.code if e.code < 500 else 502)\n    except (urllib.error.URLError, OSError):\n        raise Erro("Sem ligação à internet. Verifique a ligação e tente de novo.", 503)\n\n# ---------- sessão guardada neste PC ----------\ndef _fic(pasta): return os.path.join(pasta, "sessao.json")\ndef ler_sessao(pasta):\n    try:\n        with open(_fic(pasta), encoding="utf-8") as f: return json.load(f)\n    except Exception: return None\ndef gravar_sessao(pasta, d, user=None):\n    s = {"access_token": d["access_token"], "refresh_token": d["refresh_token"],\n         "expira": time.time() + int(d.get("expires_in") or 3600) - 60,\n         "user": user or d.get("user") or {}, "validado": time.time()}\n    with open(_fic(pasta) + ".tmp", "w", encoding="utf-8") as f: json.dump(s, f)\n    os.replace(_fic(pasta) + ".tmp", _fic(pasta))\n    return s\ndef apagar_sessao(pasta):\n    try: os.remove(_fic(pasta))\n    except Exception: pass\n\ndef token_valido(pasta):\n    """Devolve a sessão com um token válido (renova-o se for preciso)."""\n    s = ler_sessao(pasta)\n    if not s: raise Erro("Sem sessão.", 401)\n    if time.time() < s.get("expira", 0): return s\n    try:\n        d = _pedido("POST", "/auth/v1/token?grant_type=refresh_token", {"refresh_token": s["refresh_token"]})\n    except Erro as e:\n        if e.codigo in (400, 401, 403): apagar_sessao(pasta); raise Erro("A sessão terminou. Entre outra vez.", 401)\n        raise\n    return gravar_sessao(pasta, d)\n\n# ---------- ações ----------\ndef registar(pasta, b):\n    email = (b.get("email") or "").strip().lower(); pw = b.get("password") or ""\n    if not b.get("aceito"): raise Erro("Tem de aceitar a política de privacidade.")\n    if len(pw) < 8: raise Erro(MENSAGENS["weak_password"])\n    meta = {"nome": (b.get("nome") or "").strip()[:120], "empresa": (b.get("empresa") or "").strip()[:120],\n            "telefone": (b.get("telefone") or "").strip()[:40], "aceitou_privacidade": "sim"}\n    d = _pedido("POST", "/auth/v1/signup?redirect_to=" + urllib.parse.quote(VOLTAR),\n                {"email": email, "password": pw, "data": meta})\n    if d and d.get("access_token"):            # confirmação de email desligada: entra logo\n        gravar_sessao(pasta, d); return {"entrou": True}\n    if d and d.get("identities") == []:       # o Supabase não revela se o email existe: avisamos de forma neutra\n        return {"confirmar": True, "email": email}\n    return {"confirmar": True, "email": email}\n\ndef entrar(pasta, b):\n    d = _pedido("POST", "/auth/v1/token?grant_type=password",\n                {"email": (b.get("email") or "").strip().lower(), "password": b.get("password") or ""})\n    gravar_sessao(pasta, d); return {"entrou": True}\n\ndef reenviar(b):\n    _pedido("POST", "/auth/v1/resend", {"type": "signup", "email": (b.get("email") or "").strip().lower(),\n                                        "options": {"email_redirect_to": VOLTAR}})\n    return {"ok": True}\n\ndef recuperar(b):\n    _pedido("POST", "/auth/v1/recover?redirect_to=" + urllib.parse.quote(VOLTAR), {"email": (b.get("email") or "").strip().lower()})\n    return {"ok": True}\n\ndef sessao_do_link(pasta, b):\n    """Os links dos emails voltam ao programa com a sessão no endereço (#access_token=…)."""\n    at, rt = b.get("access_token"), b.get("refresh_token")\n    if not at or not rt: raise Erro("Link inválido ou expirado.")\n    u = _pedido("GET", "/auth/v1/user", token=at)\n    gravar_sessao(pasta, {"access_token": at, "refresh_token": rt, "expires_in": b.get("expires_in") or 3600}, u)\n    return {"ok": True, "tipo": b.get("type") or ""}\n\ndef estado(pasta, versao):\n    s = ler_sessao(pasta)\n    if not s: return {"sessao": False}\n    try:\n        s = token_valido(pasta)\n        u = s.get("user") or {}\n        p = _pedido("GET", "/rest/v1/perfis?select=*&id=eq." + urllib.parse.quote(u.get("id", "")), token=s["access_token"])\n        perfil = p[0] if p else {}\n        if not perfil.get("ativo", True):\n            return {"sessao": True, "bloqueado": True, "email": u.get("email")}\n        if perfil and (perfil.get("ultima_versao") != versao or not str(perfil.get("ultimo_acesso") or "").startswith(time.strftime("%Y-%m-%d", time.gmtime()))):\n            try:\n                _pedido("PATCH", "/rest/v1/perfis?id=eq." + u["id"], {"ultima_versao": versao, "ultimo_acesso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},\n                        token=s["access_token"], extra={"Prefer": "return=minimal"})\n            except Erro: pass\n        s["validado"] = time.time(); s["perfil"] = perfil\n        with open(_fic(pasta), "w", encoding="utf-8") as f: json.dump(s, f)\n        return {"sessao": True, "email": u.get("email"), "perfil": perfil, "criado": u.get("created_at")}\n    except Erro as e:\n        if e.codigo == 401: return {"sessao": False, "msg": e.msg}\n        # sem internet: continua com a sessão guardada durante uns dias\n        s = ler_sessao(pasta) or {}\n        if time.time() - s.get("validado", 0) < OFFLINE_DIAS * 86400:\n            return {"sessao": True, "offline": True, "email": (s.get("user") or {}).get("email"), "perfil": s.get("perfil") or {}}\n        return {"sessao": False, "msg": "Sem ligação à internet há mais de %d dias. Ligue-se para continuar." % OFFLINE_DIAS}\n\ndef guardar_perfil(pasta, b):\n    s = token_valido(pasta); uid = (s.get("user") or {}).get("id", "")\n    novo = {k: (b.get(k) or "").strip()[:120] for k in ("nome", "empresa", "telefone") if k in b}\n    _pedido("PATCH", "/rest/v1/perfis?id=eq." + uid, novo, token=s["access_token"], extra={"Prefer": "return=minimal"})\n    return {"ok": True}\n\ndef mudar_palavra_passe(pasta, b):\n    pw = b.get("password") or ""\n    if len(pw) < 8: raise Erro(MENSAGENS["weak_password"])\n    s = token_valido(pasta)\n    _pedido("PUT", "/auth/v1/user", {"password": pw}, token=s["access_token"])\n    return {"ok": True}\n\ndef mudar_email(pasta, b):\n    s = token_valido(pasta)\n    _pedido("PUT", "/auth/v1/user?redirect_to=" + urllib.parse.quote(VOLTAR), {"email": (b.get("email") or "").strip().lower()}, token=s["access_token"])\n    return {"ok": True}\n\ndef sair(pasta):\n    s = ler_sessao(pasta)\n    if s:\n        try: _pedido("POST", "/auth/v1/logout", {}, token=s["access_token"])\n        except Erro: pass\n    apagar_sessao(pasta); return {"ok": True}\n\ndef apagar_conta(pasta):\n    s = token_valido(pasta)\n    _pedido("POST", "/rest/v1/rpc/apagar_minha_conta", {}, token=s["access_token"])\n    apagar_sessao(pasta); return {"ok": True}\n'
# <<< conta.py
import types as _types
contas = _types.ModuleType("contas"); exec(compile(CONTA_PY, "conta.py", "exec"), contas.__dict__)
PORTA = 8766
PASTA = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.path.join(PASTA, "config.json")
URL = "http://127.0.0.1:%d/" % PORTA
API = os.environ.get("IMPORTA_API", "https://api.firecrawl.dev")
ultimo_sinal = time.time()
ativos = 0
trinco = threading.Lock()

def ler_config():
    try:
        with open(CONFIG, encoding="utf-8") as f: return json.load(f)
    except Exception: return {}

def gravar_config(c):
    with open(CONFIG, "w", encoding="utf-8") as f: json.dump(c, f)

def firecrawl_md(url, opcoes, chave):
    """Pede ao Firecrawl o texto (markdown) de uma página ou PDF."""
    corpo = dict(opcoes); corpo["url"] = url
    for versao in ("v2", "v1"):
        pedido = urllib.request.Request("%s/%s/scrape" % (API, versao), data=json.dumps(corpo).encode(), method="POST",
            headers={"Authorization": "Bearer " + chave, "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(pedido, timeout=180) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
            md = (d.get("data") or {}).get("markdown")
            if md: return md
            raise RuntimeError(d.get("error") or "sem texto")
        except urllib.error.HTTPError as e:
            if e.code == 404 and versao == "v2": continue
            try: msg = json.loads(e.read().decode("utf-8", "replace")).get("error") or ""
            except Exception: msg = ""
            if e.code == 400 and corpo.get("parsers") != ["pdf"]:   # opções não aceites: tenta a forma simples
                corpo["parsers"] = ["pdf"]; corpo.pop("pdfOptions", None)
                return firecrawl_md(url, corpo, chave)
            raise RuntimeError(("HTTP %d %s" % (e.code, msg)).strip())

def creditos(chave):
    """Créditos que restam na conta Firecrawl desta chave. Devolve dict; levanta RuntimeError("CHAVE") se a chave for inválida."""
    for versao in ("v2", "v1"):
        pedido = urllib.request.Request("%s/%s/team/credit-usage" % (API, versao), headers={"Authorization": "Bearer " + chave})
        try:
            with urllib.request.urlopen(pedido, timeout=20) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            if e.code == 404 and versao == "v2": continue
            if e.code in (401, 403): raise RuntimeError("CHAVE")
            raise RuntimeError("HTTP %d" % e.code)
        x = d.get("data") or {}
        rest = x.get("remainingCredits", x.get("remaining_credits"))
        if rest is None: raise RuntimeError(d.get("error") or "sem dados")
        info = {"restantes": rest, "plano": x.get("planCredits", x.get("plan_credits")), "fim": x.get("billingPeriodEnd", x.get("billing_period_end"))}
        try:   # pedidos em simultâneo do plano (opcional)
            p2 = urllib.request.Request("%s/v2/team/queue-status" % API, headers={"Authorization": "Bearer " + chave})
            with urllib.request.urlopen(p2, timeout=10) as r2:
                qd = json.loads(r2.read().decode("utf-8", "replace"))
            info["simultaneos"] = qd.get("maxConcurrency")
        except Exception: pass
        return info
    raise RuntimeError("sem dados")

ISV = {"a_verificar": False}
def verificar_isv():
    """Confirma nas Finanças as tabelas do ISV e do IUC. Só termina (a_verificar=False) quando as duas estão verificadas."""
    global ISV
    chave = ler_config().get("chave")
    if ISV.get("a_verificar") and ISV.get("_corre"): return
    ISV = dict(ISV, a_verificar=True, _corre=True)
    fc = lambda url, op: firecrawl_md(url, op, chave)
    sys.path.insert(0, PASTA)
    res = {}
    def isv():
        try:
            import isv_oficial
            res["isv"] = isv_oficial.verificar(PASTA, chave, fc)
        except Exception as e:
            res["isv"] = {"erro": "Verificação das tabelas de ISV falhou: %s" % e}
    def iuc():
        try:
            import iuc_oficial
            res["iuc"] = iuc_oficial.verificar(PASTA, chave, fc)
        except Exception as e:
            res["iuc"] = {"erro": "Verificação das tabelas do IUC falhou: %s" % e}
    fios = [threading.Thread(target=isv, daemon=True), threading.Thread(target=iuc, daemon=True)]   # as duas ao mesmo tempo
    for t in fios: t.start()
    for t in fios: t.join()
    novo = res["isv"]; novo["iuc"] = res["iuc"]
    novo["a_verificar"] = False
    ISV = novo
    for nome, x in (("ISV", novo), ("IUC", novo.get("iuc") or {})):
        if x.get("erro"):
            try:
                with open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8") as h: h.write(time.strftime("%Y-%m-%d %H:%M ") + nome + ": " + str(x["erro"]) + "\n")
            except Exception: pass

def firecrawl(url, chave):
    """Pede a pagina ao Firecrawl. Devolve (html, None) ou (None, mensagem)."""
    corpo = json.dumps({"url": url, "formats": ["rawHtml"], "onlyMainContent": False}).encode()
    ultimo = "erro desconhecido"
    for tentativa in range(6):
        for versao in ("v2", "v1"):
            pedido = urllib.request.Request("%s/%s/scrape" % (API, versao), data=corpo, method="POST",
                headers={"Authorization": "Bearer " + chave, "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(pedido, timeout=150) as r:
                    d = json.loads(r.read().decode("utf-8", "replace"))
                h = (d.get("data") or {}).get("rawHtml")
                if h: return h, None
                ultimo = d.get("error") or "o Firecrawl nao devolveu a pagina"
                break
            except urllib.error.HTTPError as e:
                try: msg = json.loads(e.read().decode("utf-8", "replace")).get("error", "")
                except Exception: msg = ""
                if e.code == 404 and versao == "v2": continue          # API antiga: tenta v1
                if e.code == 401: return None, "CHAVE"                 # chave errada
                if e.code == 402: return None, "CREDITOS"              # sem creditos
                ultimo = "HTTP %d %s" % (e.code, msg)
                if e.code == 429:                                     # demasiados pedidos ao mesmo tempo
                    try: espera = float(e.headers.get("Retry-After") or 0)
                    except Exception: espera = 0
                    time.sleep(min(30, max(espera, 5 + 5 * tentativa)))
                elif e.code < 500: return None, ultimo
                break
            except Exception as e:
                ultimo = str(e); break
        time.sleep(1.5 * (tentativa + 1))
    return None, ultimo

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def enviar(self, codigo, obj, tipo="application/json; charset=utf-8"):
        dados = obj if isinstance(obj, bytes) else json.dumps(obj).encode()
        self.send_response(codigo); self.send_header("Content-Type", tipo)
        self.send_header("Cache-Control", "no-store"); self.send_header("Content-Length", str(len(dados)))
        self.end_headers(); self.wfile.write(dados)
    def corpo(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}")
    def do_GET(self):
        global ultimo_sinal
        ultimo_sinal = time.time()
        if self.path == "/api/conta":
            if os.environ.get("IMPORTA_CONTA") == "off":
                return self.enviar(200, {"sessao": True, "teste": True, "email": "teste@importpro", "perfil": {"nome": "Teste", "plano": "teste"}})
            return self.enviar(200, contas.estado(PASTA, VERSAO))
        if self.path in ("/", "/index.html") or self.path.startswith("/?"):
            with open(os.path.join(PASTA, "index.html"), "rb") as f:
                return self.enviar(200, f.read(), "text/html; charset=utf-8")
        if self.path == "/api/estado":
            ch = ler_config().get("chave") or ""
            return self.enviar(200, {"chave": bool(ch), "fim": ch[-4:] if ch else "", "versao": VERSAO,
                                    "instalado_em": time.strftime("%d/%m/%Y %H:%M", time.localtime(os.path.getmtime(os.path.join(PASTA, "servidor.py"))))})
        if self.path == "/api/creditos":
            ch = ler_config().get("chave")
            if not ch: return self.enviar(200, {"erro": "SEMCHAVE"})
            conta = ler_config().get("conta", "")
            try: return self.enviar(200, dict(creditos(ch), conta=conta))
            except Exception as e: return self.enviar(200, {"erro": str(e), "conta": conta})
        if self.path == "/api/isv":
            return self.enviar(200, ISV)
        if self.path.startswith("/api/atualizacao"):
            global ATUAL, ATUAL_EM
            # cada vez que a janela abre, volta a procurar (no máximo 1 vez por minuto)
            if "novo=1" in self.path and (time.time() - ATUAL_EM > 60 or "forcar=1" in self.path) and "ativo" in ATUAL:
                ATUAL = {}; threading.Thread(target=procurar_atualizacao, daemon=True).start()
            r = {k: v for k, v in ATUAL.items() if k not in ("pacote", "sha256")}
            try:   # acabou de ser atualizado? mostra uma vez o que mudou
                fic = os.path.join(PASTA, "atualizado.json")
                with open(fic, encoding="utf-8") as h: feito = json.load(h)
                if feito.get("versao") == VERSAO: r["feito"] = feito
                os.remove(fic)
            except Exception: pass
            return self.enviar(200, r)
        if self.path == "/api/favoritos":
            try:
                with open(os.path.join(PASTA, "favoritos.json"), encoding="utf-8") as f: return self.enviar(200, {"lista": json.load(f)})
            except Exception: return self.enviar(200, {"lista": []})
        if self.path == "/api/vivo":
            return self.enviar(200, {"ok": True})
        self.enviar(404, {"erro": "nao existe"})
    def do_POST(self):
        global ultimo_sinal, ativos
        ultimo_sinal = time.time()
        if self.path == "/api/chave":
            corpo = self.corpo()
            if corpo.get("remover"):
                c = ler_config(); c.pop("chave", None); c.pop("conta", None); gravar_config(c)
                return self.enviar(200, {"ok": True})
            if "conta" in corpo and not corpo.get("chave"):
                c = ler_config(); c["conta"] = str(corpo.get("conta", "")).strip()[:120]; gravar_config(c)
                return self.enviar(200, {"ok": True})
            chave = str(corpo.get("chave", "")).strip()
            if not chave.startswith("fc-"): return self.enviar(400, {"erro": "A chave do Firecrawl começa por fc-"})
            info = None
            try: info = creditos(chave)
            except RuntimeError as e:
                if str(e) == "CHAVE": return self.enviar(400, {"erro": "O Firecrawl não aceitou esta chave. Confirme que a copiou inteira."})
            except Exception: pass   # sem ligação: guarda na mesma
            c = ler_config(); c["chave"] = chave; c["conta"] = str(corpo.get("conta", "")).strip()[:120]; gravar_config(c)
            threading.Thread(target=verificar_isv, daemon=True).start()
            return self.enviar(200, {"ok": True, "creditos": info})
        if self.path.startswith("/api/conta/"):
            acao = self.path.rsplit("/", 1)[1]; b = self.corpo()
            f = {"registar": lambda: contas.registar(PASTA, b), "entrar": lambda: contas.entrar(PASTA, b),
                 "reenviar": lambda: contas.reenviar(b), "recuperar": lambda: contas.recuperar(b),
                 "link": lambda: contas.sessao_do_link(PASTA, b), "perfil": lambda: contas.guardar_perfil(PASTA, b),
                 "palavra_passe": lambda: contas.mudar_palavra_passe(PASTA, b), "email": lambda: contas.mudar_email(PASTA, b),
                 "sair": lambda: contas.sair(PASTA), "apagar": lambda: contas.apagar_conta(PASTA)}.get(acao)
            if not f: return self.enviar(404, {"erro": "ação desconhecida"})
            try: return self.enviar(200, f())
            except contas.Erro as e: return self.enviar(e.codigo, {"erro": e.msg})
            except Exception as e:
                registar("Conta (%s) falhou: %s" % (acao, e)); return self.enviar(500, {"erro": "Ocorreu um erro. Tente de novo."})
        if self.path == "/api/atualizar":
            if not ATUAL.get("nova"): return self.enviar(400, {"erro": "não há versão nova"})
            try:
                import atualizar
                atualizar.aplicar(PASTA, ATUAL)
            except Exception as e:
                registar("Atualização falhou: %s" % e)
                return self.enviar(500, {"erro": "Não consegui atualizar: %s" % e})
            threading.Timer(0.8, reiniciar).start()
            return self.enviar(200, {"ok": True, "versao": ATUAL.get("versao")})
        if self.path == "/api/favoritos":
            lista = self.corpo().get("lista")
            if not isinstance(lista, list): return self.enviar(400, {"erro": "lista inválida"})
            fic = os.path.join(PASTA, "favoritos.json")
            with open(fic + ".tmp", "w", encoding="utf-8") as f: json.dump(lista, f, ensure_ascii=False)
            os.replace(fic + ".tmp", fic)
            return self.enviar(200, {"ok": True})
        if self.path == "/api/isv":
            threading.Thread(target=verificar_isv, daemon=True).start()
            return self.enviar(200, {"ok": True})
        if self.path == "/api/excel":
            try: caminho = gerar_excel(self.corpo())
            except Exception as e:
                import traceback
                try:
                    with open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8") as f: f.write(traceback.format_exc())
                except Exception: pass
                return self.enviar(500, {"erro": "%s: %s" % (type(e).__name__, e)})
            return self.enviar(200, {"ficheiro": caminho})
        if self.path == "/api/scrape":
            chave = ler_config().get("chave")
            if not chave: return self.enviar(400, {"erro": "CHAVE"})
            url = str(self.corpo().get("url", ""))
            with trinco: ativos += 1
            try: html, erro = firecrawl(url, chave)
            finally:
                with trinco: ativos -= 1
                ultimo_sinal = time.time()
            if html: return self.enviar(200, {"rawHtml": html})
            return self.enviar(502, {"erro": erro})
        self.enviar(404, {"erro": "nao existe"})

def pasta_transferencias():
    try:   # pasta "Transferências" verdadeira do Windows (mesmo se estiver no OneDrive)
        import ctypes, uuid
        from ctypes import wintypes
        guid = uuid.UUID("{374DE290-123F-4565-9164-39C4925E467B}")
        class GUID(ctypes.Structure):
            _fields_ = [("a", wintypes.DWORD), ("b", wintypes.WORD), ("c", wintypes.WORD), ("d", ctypes.c_ubyte * 8)]
        g = GUID(guid.fields[0], guid.fields[1], guid.fields[2], (ctypes.c_ubyte * 8)(*guid.bytes[8:]))
        p = ctypes.c_wchar_p()
        if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(g), 0, None, ctypes.byref(p)) == 0 and os.path.isdir(p.value):
            return p.value
    except Exception: pass
    for p in (os.path.join(os.path.expanduser("~"), "Downloads"), os.path.expanduser("~")):
        if os.path.isdir(p): return p
    return PASTA

def gerar_excel(d):
    sys.path.insert(0, PASTA)
    import relatorio
    pasta = pasta_transferencias()
    c = d.get("criterios", {})
    nome = "ImportPro %s %s %s.xlsx" % (c.get("marca", ""), c.get("modelo", ""), time.strftime("%Y-%m-%d %Hh%M %Ss"))
    nome = "".join(ch for ch in nome if ch not in '\\/:*?"<>|')
    caminho = os.path.join(pasta, nome)
    relatorio.gerar(d, caminho)
    try: os.startfile(caminho)          # abre no Excel (Windows)
    except Exception: pass
    return caminho

def abrir_janela():
    for p in (r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe", r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe",
              r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe", r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
              r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe", r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"):
        p = os.path.expandvars(p)
        if os.path.exists(p):
            try:
                subprocess.Popen([p, "--app=" + URL, "--window-size=1400,900"]); return
            except Exception: pass
    webbrowser.open(URL)

def registar(msg):
    try:
        with open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8") as f: f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except Exception: pass

def procurar_atualizacao():
    global ATUAL, ATUAL_EM
    ATUAL_EM = time.time()
    try:
        sys.path.insert(0, PASTA)
        import atualizar
        ATUAL = atualizar.verificar(URL_ATUALIZACOES, VERSAO)
    except Exception as e:
        ATUAL = {"ativo": bool(URL_ATUALIZACOES), "erro": str(e)}

def reiniciar():
    # arranca o programa novo (já atualizado) e fecha este; a janela recarrega sozinha
    env = dict(os.environ, IMPORTA_SEM_JANELA="1", IMPORTA_REINICIO="1")
    try: srv.server_close()
    except Exception: pass
    flags = 0x08000000 if os.name == "nt" else 0          # CREATE_NO_WINDOW
    subprocess.Popen([sys.executable, os.path.join(PASTA, "servidor.py")], env=env, cwd=PASTA, creationflags=flags)
    os._exit(0)

def vigiar():
    # fecha o servidor quando a janela da calculadora esta fechada ha 3 minutos
    while True:
        time.sleep(20)
        if ativos == 0 and time.time() - ultimo_sinal > 180: os._exit(0)

class Servidor(ThreadingHTTPServer):
    daemon_threads = True
    def handle_error(self, request, client_address):
        try:
            import traceback
            with open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + traceback.format_exc() + "\n")
        except Exception: pass

if __name__ == "__main__":
    if sys.stderr is None or sys.stdout is None:          # pythonw: sem consola
        try:
            sys.stderr = sys.stdout = open(os.path.join(PASTA, "erros.log"), "a", encoding="utf-8")
        except Exception: pass
    reinicio = bool(os.environ.pop("IMPORTA_REINICIO", ""))
    if not reinicio:
        s = socket.socket(); s.settimeout(1)
        a_correr = s.connect_ex(("127.0.0.1", PORTA)) == 0; s.close()
        if a_correr:
            abrir_janela(); sys.exit(0)        # ja esta a correr: so abre a janela
    srv = None
    for _ in range(40):                        # depois de uma atualização, espera que o programa antigo liberte a porta
        try: srv = Servidor(("127.0.0.1", PORTA), H); break
        except OSError:
            if not reinicio: raise
            time.sleep(0.25)
    if srv is None: sys.exit(1)
    threading.Thread(target=procurar_atualizacao, daemon=True).start()
    threading.Thread(target=vigiar, daemon=True).start()
    try:
        with open(os.path.join(PASTA, "isv.json"), encoding="utf-8") as h: ISV = dict(json.load(h), a_verificar=True)
        try:
            with open(os.path.join(PASTA, "iuc.json"), encoding="utf-8") as h: ISV["iuc"] = json.load(h)
        except Exception: pass
    except Exception: pass
    threading.Thread(target=verificar_isv, daemon=True).start()
    if not os.environ.get("IMPORTA_SEM_JANELA"): threading.Timer(0.6, abrir_janela).start()
    srv.serve_forever()
